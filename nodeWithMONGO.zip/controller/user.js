const User = require("../Model/user")

const getLogin = (req , res) => {
    return res.render('login.ejs')
}

const getSignUp = (req , res) => {
    return res.render('signup.ejs')
}

const postLogin = async (req , res ) => {
    const { email , password } = req.body

    const user = await User.findOne({ email })

    if(!user){
        return res.redirect('/user/signup')
    }

    res.cookie("user" , user )
    return res.redirect("/blogs")
}

module.exports = { getLogin , getSignUp , postLogin }