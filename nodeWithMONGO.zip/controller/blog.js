

const getBlog = (req , res) => {
    return res.render("blog.ejs")
}

module.exports = { getBlog }