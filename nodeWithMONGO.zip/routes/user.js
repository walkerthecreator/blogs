const express = require("express")
const router = express.Router()
const { getLogin , getSignUp, postLogin } = require("../controller/user")

router.get('/login' , getLogin )
router.get('/signup' , getSignUp )

router.post('/login' , postLogin)

module.exports = router